// Define a class called Insurance that inherits from the Bank class
public class Insurance extends Bank {
    // Constructor that calls the Bank constructor
    public Insurance(String accountType, double accountBalance) {
        // Call the Bank constructor to initialize the account type and balance
        super(accountType, accountBalance);
    }

    // Method to indicate that the account is covered by insurance
    public void cover() {
        // Print a message indicating that the account is covered
        System.out.println("You are covered");
    }
}
