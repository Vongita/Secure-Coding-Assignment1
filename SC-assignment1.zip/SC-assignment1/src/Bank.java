// Define a class called Bank to represent a bank account
public class Bank {
    // Fields to store the account type and balance
    private String accountType;
    private double accountBalance;

    // Parameterized constructor to initialize the account type and balance
    public Bank(String accountType, double accountBalance) {
        // Set the account type and balance using the constructor parameters
        this.accountType = accountType;
        this.accountBalance = accountBalance;
    }

    // Method to deposit money into the account
    public double deposit(double amount) {
        // Add the deposit amount to the account balance
        accountBalance += amount;
        // Return the updated account balance
        return accountBalance;
    }

    // Method to withdraw money from the account
    public double withdrawal(double amount) {
        // Check if the withdrawal amount exceeds the account balance
        if (amount > accountBalance) {
            // Print an error message if the account balance is insufficient
            System.out.println("Insufficient balance");
            // Return the current account balance
            return accountBalance;
        }
        // Subtract the withdrawal amount from the account balance
        accountBalance -= amount;
        // Return the updated account balance
        return accountBalance;
    }

    // Method to display the account information
    public void display() {
        // Print the account type and balance
        System.out.println("The account type is " + accountType + " and the balance is " + accountBalance);
    }
}


