// Define a main class to test the Bank and Insurance classes
public class Main {
    // Main method to test the classes
    public static void main(String[] args) {
        // Create an instance of the Bank class
        Bank bank = new Bank("VTK", 230693); // Replace with your initials and reg number

        // Invoke the display method to print the account information
        bank.display();
    }
}